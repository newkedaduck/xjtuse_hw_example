import math
"""
滑动平均法调整模型——改变第一次选取的误差值
"""
def calculate_angle(r1, rho1, r2, rho2):
    """
    模拟发射信号无人机向接收无人机传递的方位角信息
    :param r1: 发射信号无人机极径
    :param rho1: 发射信号无人机极角
    :param r2: 接收信号无人机极径
    :param rho2: 接收射信号无人机极角
    :return: 方位角
    """
    # 根据正弦定理
    rho = abs(rho2 - rho1)      # 极角差
    if (rho > 180):
        rho = 360 - rho
    tgx = r1 * math.sin(math.radians(rho)) / (r2 - r1 * math.cos(math.radians(rho)))
    return math.atan(tgx)

def calculate_adjustment(r1, alpha1, r2, alpha2, r3, alpha3):
    """
    调整方案
    :param r1:
    :param alpha1:
    :param r2:
    :param alpha2:
    :param r3:
    :param alpha3:
    :return:
    """
    # 单次移动值
    dta_rho = 0.0005
    dta_r = 0.0005
    # 方位角信息
    # if (alpha2 == 0):
    #     angle_F0F2F1 = calculate_angle(r1, alpha1, r2, alpha2 + 360)
    # else:
    #     angle_F0F2F1 = calculate_angle(r1, alpha1, r2, alpha2)
    #
    # if (alpha3 == 0):
    #     angle_F0F2F3 = calculate_angle(r3, alpha3 + 360, r2, alpha2)
    # else:
    #     angle_F0F2F3 = calculate_angle(r3, alpha3, r2, alpha2)
    angle_F0F2F1 = calculate_angle(r1, alpha1, r2, alpha2)
    angle_F0F2F3 = calculate_angle(r3, alpha3, r2, alpha2)
    abs_angle = abs(angle_F0F2F1 - angle_F0F2F3)
    abs_r = abs(angle_F0F2F1 - math.radians(70))
    # 角度调整方案
    while(abs_angle > 10E-6 and abs_r > 10E-7):
        alphaA1 = calculate_angle(r1, alpha1, r2 + dta_r, alpha2 + dta_rho)
        alphaA2 = calculate_angle(r3, alpha3, r2 + dta_r, alpha2 + dta_rho)
        alphaB1 = calculate_angle(r1, alpha1, r2 + dta_r, alpha2 - dta_rho)
        alphaB2 = calculate_angle(r3, alpha3, r2 + dta_r, alpha2 - dta_rho)
        alphaC1 = calculate_angle(r1, alpha1, r2 + dta_r, alpha2 - dta_rho)
        alphaC2 = calculate_angle(r3, alpha3, r2 + dta_r, alpha2 - dta_rho)
        alphaD1 = calculate_angle(r1, alpha1, r2 - dta_r, alpha2 - dta_rho)
        alphaD2 = calculate_angle(r3, alpha3, r2 - dta_r, alpha2 - dta_rho)
        absA = abs(alphaA1 - alphaA2)
        absB = abs(alphaB1 - alphaB2)
        absC = abs(alphaC1 - alphaC2)
        absD = abs(alphaD1 - alphaD2)
        abs_list = []
        abs_list.append(absA)
        abs_list.append(absB)
        abs_list.append(absC)
        abs_list.append(absD)
        index = abs_list.index(min(abs_list))
        if index == 0:
            r2 = r2 + dta_r
            alpha2 = alpha2 + dta_rho
            abs_angle = abs(alphaA1 - alphaA2)
            abs_r = abs(alphaA1 - math.radians(70))
        elif index == 1:
            r2 = r2 + dta_r
            alpha2 = alpha2 - dta_rho
            abs_angle = abs(alphaB1 - alphaB2)
            abs_r = abs(alphaB1 - math.radians(70))
        elif index == 2:
            r2 = r2 - dta_r
            alpha2 = alpha2 + dta_rho
            abs_angle = abs(alphaC1 - alphaC2)
            abs_r = abs(alphaC1 - math.radians(70))
        elif index == 3:
            r2 = r2 - dta_r
            alpha2 = alpha2 - dta_rho
            abs_angle = abs(alphaD1 - alphaD2)
            abs_r = abs(alphaD1 - math.radians(70))

        # angle_F0F2F1 = calculate_angle(r1, alpha1, r2, alpha2)
        # angle_F0F2F3 = calculate_angle(r3, alpha3, r2, alpha2)
        # abs_angle = abs(angle_F0F2F1 - angle_F0F2F3)
    # 极径调整方案

    # abs_r = abs(angle_F0F2F1 - math.radians(70))
    # while(abs_r > 10E-7):
    #     if angle_F0F2F1 > math.radians(70):
    #         r2 = r2 + dta_r
    #     elif angle_F0F2F1 < math.radians(70):
    #         r2 = r2 - dta_r
    #     else:
    #         break
    #     angle_F0F2F1 = calculate_angle(r1, alpha1, r2, alpha2)
    #     abs_r = abs(angle_F0F2F1 - math.radians(70))
    # average_r = (r1 + r3) / 2

    average_r = r2
    return average_r, alpha2

def polar_to_cartesian(r, theta):
    """将极坐标转换为笛卡尔坐标"""
    x = r * math.cos(math.radians(theta))
    y = r * math.sin(math.radians(theta))
    return x, y

def euclidean_distance(polar1, polar2):
    """计算两个极坐标点之间的欧式距离"""
    cartesian1 = polar_to_cartesian(*polar1)
    cartesian2 = polar_to_cartesian(*polar2)
    distance = math.sqrt((cartesian2[0] - cartesian1[0])**2 + (cartesian2[1] - cartesian1[1])**2)
    return distance

def init_error(position, standard):
    error = []
    for i in range(0, len(position)):
        distance = euclidean_distance(position[i], standard[i])
        error.append(distance)
    return error

def getMin(errors: list, flag: list) -> int:
    """
    取出误差最小的值，如果误差为0不选择此点
    :param list: 误差列表
    :return: 最小误差的下标
    """
    # # 找到除去0之外的最小值
    # min_index = errors.index(min(errors))
    # if flag[min_index] == 1:
    #     return min_index
    # non_zero_values = [x for x in errors if x != 0]
    # min_value = min(non_zero_values)
    # # 找到最小值的下标
    # return errors.index(min_value)
    min_index = errors.index(min(errors))
    if flag[min_index] == 1:
        return min_index
    non_zero_values = []
    for i in range(len(flag)):
        if flag[i] == 1:
            non_zero_values.append(errors[i])
    min_value = min(non_zero_values)
    # 找到最小值的下标
    return errors.index(min_value)

def sliding_average_adjustment(uavs, standard, iterations, file):
    """
    使用滑动均值法进行无人机位置调整。
    """
    f = open(file, 'w')
    flag = [1] * 9
    for i in range(iterations):
        if i % 9 == 0:
            flag = [1] * 9
        # 初始化误差列表
        errors = init_error(uavs, standard)
        f.write(f"epoch:{i+1}\n")
        # 选择误差最小的三架无人机作为信号发射无人机
        # min_index = getMin(errors, flag)
        # flag[min_index] = 0
        min_index = errors.index(min(errors))
        f.write(f"min_index: {min_index}\n")
        for _ in range(9):
            # 根据选择的无人机进行位置调整
            F1 = uavs[min_index % 9]
            F2 = uavs[(min_index + 1) % 9]
            F3 = uavs[(min_index + 2) % 9]
            if F2 == standard[(min_index + 1) % 9]: continue
            r, rho = calculate_adjustment(F1[0], F1[1], F2[0], F2[1], F3[0], F3[1])
            uavs[(min_index+1)%9] = (r, rho)
            min_index = min_index + 1
        # 计算总误差
        errors = init_error(uavs, standard)
        total_error = sum(errors)
        j = 1
        for (R, alpha) in uavs:
            f.write(f"UAV {j}: (R={R}, alpha={alpha})\n")
            j = j + 1
        f.write(f"error: {errors}\n")
        f.write(f"total_error: {total_error}\n")
        # if i % 5 == 0 and i <= 20:
        #     f.write("[")
        #     for (R, alpha) in uavs:
        #         f.write(f"({R}, {alpha}),\n")
        #     f.write("],\n")
        # f.write(f"{total_error}")
        # f.write(",")
        if total_error < 0.001:  # 假设误差小于0.001时认为调整完成
            break
    f.close()
    return uavs


def main():
    # 初始无人机位置数据（极坐标）
    initial_positions = [
        (100, 0),  # F1
        (98, 40.1),  # F2
        (112, 80.21),  # F3
        (105, 119.75),  # F4
        (98, 159.86),  # F5
        (112, 199.96),  # F6
        (105, 240.07),  # F7
        (98, 280.17),  # F8
        (112, 320.28)  # F9
    ]
    standard_position = [
        (100, 0),
        (100, 40),
        (100, 80),
        (100, 120),
        (100, 160),
        (100, 200),
        (100, 240),
        (100, 280),
        (100, 320)
    ]

    # 无人机数量
    num_uavs = 10
    file = "qs03_moveAverage_pro.txt"
    # 执行位置调整
    adjusted_positions = sliding_average_adjustment(initial_positions, standard_position, 100, file)
    # 打印调整后的位置
    for i, (R, alpha) in enumerate(adjusted_positions):
        print(f"UAV {i}: (R={R}, alpha={alpha})")


if __name__ == "__main__":
    main()