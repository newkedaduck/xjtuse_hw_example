from QS03.q3 import calculate_adjustment, polar_to_cartesian, euclidean_distance, init_error, getMin
import math

def sliding_adjustment(uavs, standard, iterations, file, nums):
    """
    使用滑动均值法进行无人机位置调整。
    """
    f = open(file, 'a')
    flag = [1] * nums
    errors = init_error(uavs, standard)
    non_move = errors.index(min(errors))
    for i in range(iterations):
        if i % nums == 0:
            flag = [1] * nums

        f.write(f"epoch:{i + 1}\n")

        min_index = getMin(errors, flag)
        flag[min_index] = 0
        # min_index = errors.index(min(errors))
        f.write(f"min_index: {min_index}\n")
        for _ in range(nums):
            # 根据选择的无人机进行位置调整
            F1 = uavs[min_index % nums]
            F2 = uavs[(min_index + 1) % nums]
            F3 = uavs[(min_index + 2) % nums]
            if (min_index + 1) % nums == non_move: continue
            r, rho = calculate_adjustment(F1[0], F1[1], F2[0], F2[1], F3[0], F3[1], nums)
            uavs[(min_index + 1) % nums] = (r, rho)
            min_index = min_index + 1
        # 计算总误差
        errors = init_error(uavs, standard)
        total_error = sum(errors)
        j = 1
        for (R, alpha) in uavs:
            f.write(f"UAV {j}: (R={R}, alpha={alpha})\n")
            j = j + 1
        f.write(f"error: {errors}\n")
        f.write(f"total_error: {total_error}\n")
        # if i % 5 == 0 and i <= 20:
        #     f.write("[")
        #     for (R, alpha) in uavs:
        #         f.write(f"({R}, {alpha}),\n")
        #     f.write("],\n")
        # f.write(f"{total_error}")
        # f.write(",")
        if total_error < 0.001:  # 假设误差小于0.001时认为调整完成
            break
    f.close()
    return uavs


""""""""""""""""""""""""""


# 极坐标移动
def move_polar_origin(r, theta, origin_x, origin_y):
    x, y = polar_to_cartesian(r, theta)
    new_x, new_y = transform_coordinates(x, y, origin_x, origin_y)
    return cartesian_to_polar(new_x, new_y)


def polar_to_cartesian(r, theta):
    theta = math.radians(theta)
    x = r * math.cos(theta)
    y = r * math.sin(theta)
    return x, y


def cartesian_to_polar(x, y):
    r = math.sqrt(x ** 2 + y ** 2)
    theta = math.atan2(y, x)
    theta = math.degrees(theta)
    if theta < 0:
        theta = 360 + theta
    return r, theta


def transform_coordinates(old_x, old_y, new_origin_x, new_origin_y):
    new_x = old_x - new_origin_x
    new_y = old_y - new_origin_y
    return new_x, new_y


""""""""""""""""""""""""""


def main():
    standard_positions = {
        5: (0, 0),  # F5
        2: (50, 30),  # F2
        4: (50, 90),  # F4
        8: (50, 150),  # F8
        9: (50, 210),  # F9
        6: (50, 270),  # F6
        3: (50, 330),  # F3
        1: (50 * math.sqrt(3), 0),  # F1
        7: (50 * math.sqrt(3), 120),  # F7
        10: (50 * math.sqrt(3), 240),  # F10
        13: (50 * math.sqrt(3), 180),  # F13
        12: (100, 150),  # F12
        14: (100, 210),  # F14
        11: (math.sqrt(50 * 50 * 3 + 100 * 100), 180 - math.degrees(math.atan(2 / math.sqrt(3)))),  # F11
        15: (math.sqrt(50 * 50 * 3 + 100 * 100), 180 + math.degrees(math.atan(2 / math.sqrt(3))))
    }

    file_final_pos = "qs04_final_pos_test02.txt"
    writer = open(file_final_pos, 'w')
    writer.write("无人机标准位置:\n")
    for i in range(1, len(standard_positions) + 1):
        writer.write(f"FY0{i}:{standard_positions[i]}\n")
    # 无人机数量
    file = "qs04_moveAverage_test02.txt"
    # 假设5是精准的
    # step1:调整5,2,3,6,9,8,4在一个理想6等分圆上
    # 类比问题3，5为圆心0，2 4 8 9 6 3 分别为1 2 3 4 5 6
    standard_position1 = [
        (50, 30),  # F2
        (50, 90),  # F4
        (50, 150),  # F8
        (50, 210),  # F9
        (50, 270),  # F6
        (50, 330)  # F3
    ]
    initial_position1 = [
        (53, 30.2),  # F2
        (50.1, 90.22),  # F4
        (48, 149.35),  # F8
        (55, 209.25),  # F9
        (56, 270.45),  # F6
        (45, 330.22)  # F3
    ]
    # 执行位置调整
    # for i in range(len(initial_position)):
    initial_position1 = sliding_adjustment(initial_position1, standard_position1, 50, file, 6)

    # step2:同样以5为圆心，1 7 10 分别对应3等分理想圆的
    standard_position2 = [
        (50 * math.sqrt(3), 0),  # F1
        (50 * math.sqrt(3), 120),  # F7
        (50 * math.sqrt(3), 240),  # F10
    ]
    initial_position2 = [
        (50 * math.sqrt(3) + 1, 0.10),  # F1
        (50 * math.sqrt(3) - 5, 120.40),  # F7
        (50 * math.sqrt(3) + 6, 239.50),  # F10
    ]

    initial_position2 = sliding_adjustment(initial_position2, standard_position2, 30, file, 3)

    # step 3: 以1 2 3 4 5 6 7 8 9 10组成的小锥形方队类比
    # 以08为圆心
    # 6等分调整
    origin_x = -25 * math.sqrt(3)
    origin_y = 25
    initial_position3 = [
        move_polar_origin(initial_position1[1][0], initial_position1[1][1], origin_x, origin_y),  # F4
        move_polar_origin(initial_position2[1][0], initial_position2[1][1], origin_x, origin_y),  # F7
        (55, 149.43),  # F12
        (47, 210.22),  # F13
        move_polar_origin(initial_position1[3][0], initial_position1[3][1], origin_x, origin_y),  # F9
        (50, 330)  # F5
    ]
    initial_position3 = sliding_adjustment(initial_position3, standard_position1, 50, file, 6)
    # 3等分调整 2 11 14
    initial_position4 = [
        move_polar_origin(initial_position1[0][0], initial_position1[0][1], origin_x, origin_y),  # F2
        (50 * math.sqrt(3) - 4, 121.40),              # F11
        (50 * math.sqrt(3) + 5, 239.50)               # F14
    ]
    initial_position4 = sliding_adjustment(initial_position4, standard_position2, 30, file, 3)
    # 以09为圆心
    # 6等分调整 5 8 13 14 10 6
    origin_y = -25
    initial_position5 = [
        (50, 30),   # F5
        move_polar_origin(initial_position1[2][0], initial_position1[2][1], origin_x, origin_y),    # F08
        move_polar_origin(initial_position3[3][0], initial_position3[3][1], 0, -50),    # F13
        move_polar_origin(initial_position4[2][0], initial_position4[2][1], 0, -50),    # F14
        move_polar_origin(initial_position2[2][0], initial_position2[2][1], origin_x, origin_y),    # F10
        move_polar_origin(initial_position1[4][0], initial_position1[4][1], origin_x, origin_y)     # F6
    ]
    initial_position5 = sliding_adjustment(initial_position5, standard_position1, 50, file, 6)

    # 3等分调整 3 12 15
    initial_position6 = [
        move_polar_origin(initial_position1[5][0], initial_position1[5][1], origin_x, origin_y),    # F3
        move_polar_origin(initial_position3[2][0], initial_position1[2][1], 0, -50),    # F12
        (50 * math.sqrt(3) - 2, 238.50)     # F15
    ]
    initial_position6 = sliding_adjustment(initial_position6, standard_position2, 30, file, 3)

    # 最终位置转化
    writer.write("无人机调整之后的位置：\n")
    initial_positions = {}
    # 3 12 15
    initial_positions[3] = move_polar_origin(initial_position6[0][0], initial_position6[0][1], 25*math.sqrt(3), 25)
    initial_positions[12] = move_polar_origin(initial_position6[1][0], initial_position6[1][1], 25*math.sqrt(3), 25)
    initial_positions[15] = move_polar_origin(initial_position6[2][0], initial_position6[2][1], 25*math.sqrt(3), 25)
    # 5 8 13 14 10 6
    list = [5, 8, 13, 14, 10, 6]
    for i in range(len(list)):
        initial_positions[list[i]] = move_polar_origin(initial_position5[i][0], initial_position5[i][1], 25*math.sqrt(3), 25)
    # 7 4
    initial_positions[4] = move_polar_origin(initial_position3[0][0], initial_position3[0][1], 25*math.sqrt(3), -25)
    initial_positions[7] = move_polar_origin(initial_position3[1][0], initial_position3[1][1], 25*math.sqrt(3), -25)
    # 2 11
    initial_positions[2] = move_polar_origin(initial_position4[0][0], initial_position4[0][1], 25*math.sqrt(3), -25)
    initial_positions[11] = move_polar_origin(initial_position4[1][0], initial_position4[1][1], 25*math.sqrt(3), -25)
    # 8 9
    initial_positions[8] = initial_position1[2]
    initial_positions[9] = initial_position1[3]
    # 1
    initial_positions[1] = initial_position2[0]
    initial_positions[5] = (0, 0)
    for i in range(1, len(initial_positions) + 1):
        writer.write(f"FY0{i}:{initial_positions[i]}\n")
    # 打印调整后的位置
    writer.close()

if __name__ == "__main__":
    main()
