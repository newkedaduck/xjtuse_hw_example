"""
模拟两架飞机没有偏差
"""
import math

def calculate_angle(r1, rho1, r2, rho2):
    """
    模拟发射信号无人机向接收无人机传递的方位角信息
    :param r1: 发射信号无人机极径
    :param rho1: 发射信号无人机极角
    :param r2: 接收信号无人机极径
    :param rho2: 接收射信号无人机极角
    :return: 方位角
    """
    # 根据正弦定理
    rho = abs(rho2 - rho1)      # 极角差
    if (rho > 180):
        rho = 360 - rho
    tgx = r1 * math.sin(math.radians(rho)) / (r2 - r1 * math.cos(math.radians(rho)))
    return math.degrees(math.atan(tgx))

def solve_rho_theta(r1, theta1, r3, theta3, alpha1, alpha3):
    """
    模拟定位模型1
    :param r1: 左边的发射无人机
    :param theta1:
    :param r3: 右边发射无人机
    :param theta3:
    :param alpha1: 信息角1
    :param alpha3: 信息角2
    :return:
    """
    alpha1 = math.radians(alpha1)
    alpha3 = math.radians(alpha3)
    theta1 = math.radians(theta1)
    theta3 = math.radians(theta3)
    y = math.sin(alpha1)*math.sin(alpha3+theta3) - math.sin(alpha3)*math.sin(alpha1-theta1)
    x = math.sin(alpha3)*math.cos(alpha1-theta1) + math.sin(alpha1)*math.cos(alpha3+theta3)
    theta = math.degrees(math.atan(y/x))
    rho = r1 * abs(math.sin(alpha1+math.radians(theta)-theta1)/math.sin(alpha1))

    return rho, theta

def main():
    initial_positions = [
        (100, 0),  # F1
        (98, 40.1),  # F2
        (112, 80.21),  # F3
        (105, 119.75),  # F4
        (98, 159.86),  # F5
        (112, 199.96),  # F6
        (105, 240.07),  # F7
        (98, 280.17),  # F8
        (112, 320.28)  # F9
    ]
    standard_position = [
        (100, 0),
        (100, 40),
        (100, 80),
        (100, 120),
        (100, 160),
        (100, 200),
        (100, 240),
        (100, 280),
        (100, 320)
    ]
    calculate_angles = []
    for i in range(len(initial_positions)):
        alpha1 = calculate_angle(initial_positions[i%9][0], initial_positions[i%9][1], initial_positions[(i+1)%9][0], initial_positions[(i+1)%9][1])
        alpha3 = calculate_angle(initial_positions[(i+2)%9][0], initial_positions[(i+2)%9][1], initial_positions[(i+1)%9][0], initial_positions[(i+1)%9][1])
        rho, theta = solve_rho_theta(standard_position[i%9][0],standard_position[i%9][1], standard_position[(i+2)%9][0],standard_position[(i+2)%9][1] ,alpha1, alpha3)
        calculate_angles.append((rho, theta))
    for i in calculate_angles:
        print(f"{i}")

if __name__ == '__main__':
    main()