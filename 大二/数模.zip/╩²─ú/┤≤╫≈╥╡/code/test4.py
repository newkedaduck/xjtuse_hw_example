import re


# 读取文件内容的函数
def extract_total_errors(file_path):
    total_errors = []
    with open(file_path, 'r') as file:
        lines = file.readlines()

    for line in lines:
        # 使用正则表达式找到total_error的值
        match = re.search(r'total_error: (\d+\.\d+)', line)
        if match:
            # 将找到的total_error值添加到列表中
            total_errors.append(float(match.group(1)))
    return total_errors


# 写入total_errors到文件的函数
def write_total_errors_to_file(total_errors, output_file_path):
    with open(output_file_path, 'w') as file:
        for error in total_errors:
            file.write(f'{error},\n')


# 主程序
if __name__ == '__main__':
    # 指定输入文件和输出文件的路径
    input_file_path = 'QS04/qs04_moveAverage_test02.txt'  # 替换为你的输入文件路径
    output_file_path = 'total_errors.txt'

    # 提取total_errors
    total_errors = extract_total_errors(input_file_path)

    # 将提取的total_errors写入到文件
    write_total_errors_to_file(total_errors, output_file_path)

    print(f'Total errors have been written to {output_file_path}')