import math
import matplotlib.pyplot as plt
from QS04 import move_polar_origin as trans

def plot_points(initial_coords, final_coords):
    initial_rs, initial_thetas = zip(*initial_coords)
    final_rs, final_thetas = zip(*final_coords)

    initial_xs = [r * math.cos(math.radians(theta)) for r, theta in initial_coords]
    initial_ys = [r * math.sin(math.radians(theta)) for r, theta in initial_coords]

    final_xs = [r * math.cos(math.radians(theta)) for r, theta in final_coords]
    final_ys = [r * math.sin(math.radians(theta)) for r, theta in final_coords]

    plt.figure(figsize=(8, 6))
    plt.title("The initial and final position of the drone")

    plt.scatter(initial_xs, initial_ys, color='blue', label='Initial Position')
    plt.scatter(final_xs, final_ys, color='red', label='Final Position')

    plt.xlabel('X')
    plt.ylabel('Y')
    plt.axhline(0, color='black',linewidth=0.5)
    plt.axvline(0, color='black',linewidth=0.5)
    plt.grid(color = 'gray', linestyle = '--', linewidth = 0.5)
    plt.legend()
    plt.show()

# 输入初始位置和最终位置的极坐标列表
final_coords = [
    (87.60254037844386, 0.1),
    (50.10014999990374, 30.21930000000064),
    (49.83109436497887, 330.11092888851095),
    (50.000517951394656, 90.00113393691716),
    (0, 0),
    (49.999445744087446, 270.0001382043729),
    (86.60246770540434, 120.00033407456412),
    (50.09925000006969, 150.22144999978124),
    (50.09944999983732, 210.22094999975627),
    (86.60250256253784, 240.0000707725058),
    (132.31963285670307, 130.98593729164097),
    (99.99971326921059, 150.1107248891652),
    (86.60258367701321, 179.99954961795225),
    (100.00028495856293, 209.99979395549272),
    (132.1611548793485, 229.16980675798783)
]
standard_coords = [
    (86.60254037844386, 0),
    (50, 30),
    (50, 330),
    (50, 90),
    (0, 0),
    (50, 270),
    (86.60254037844386, 120),
    (50, 150),
    (50, 210),
    (86.60254037844386, 240),
    (132.28756555322954, 130.8933946491309),
    (100, 150),
    (86.60254037844386, 180),
    (100, 210),
    (132.28756555322954, 229.1066053508691)
]
initial_coords = [
    (53, 30.2),  # F2
    (50.1, 90.22),  # F4
    (48, 149.35),  # F8
    (55, 209.25),  # F9
    (56, 270.45),  # F6
    (45, 330.22),  # F3
    (50 * math.sqrt(3) + 1, 0.10),  # F1
    (50 * math.sqrt(3) - 5, 120.40),  # F7
    (50 * math.sqrt(3) + 6, 239.50),  # F10
    trans(55, 149.43, 25 * math.sqrt(3), -25),  # F12
    trans(47, 210.22, 25 * math.sqrt(3), -25),  # F13
    trans(50 * math.sqrt(3) - 4, 121.40, 25 * math.sqrt(3), -25),   # F11
    trans(50 * math.sqrt(3) - 2, 238.50, 25*math.sqrt(3), 25),      # F15
    trans(50 * math.sqrt(3) + 5, 239.50, 25*math.sqrt(3), -25)      # F14
    ]

initial_dict = {
    2:(53, 30.2),  # F2
    4:(50.1, 90.22),  # F4
    8:(48, 149.35),  # F8
    9:(55, 209.25),  # F9
    6:(56, 270.45),  # F6
    3:(45, 330.22),  # F3
    1:(50 * math.sqrt(3) + 1, 0.10),  # F1
    7:(50 * math.sqrt(3) - 5, 120.40),  # F7
    10:(50 * math.sqrt(3) + 6, 239.50),  # F10
    12:trans(55, 149.43, 25 * math.sqrt(3), -25),  # F12
    13:trans(47, 210.22, 25 * math.sqrt(3), -25),  # F13
    11:trans(50 * math.sqrt(3) - 4, 121.40, 25 * math.sqrt(3), -25),  # F11
    15:trans(50 * math.sqrt(3) - 2, 238.50, 25 * math.sqrt(3), 25),  # F15
    14:trans(50 * math.sqrt(3) + 5, 239.50, 25 * math.sqrt(3), -25),  # F14
    5:(0,0)
}
# 画出点
plot_points(initial_coords, final_coords)
for i in range(0, len(final_coords)):
    print(f"{final_coords[i][1]} & ")