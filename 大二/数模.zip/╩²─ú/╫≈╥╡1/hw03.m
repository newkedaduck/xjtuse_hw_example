clear;
clc;
P=[4 1;5 18];         %将 de ar表示成向量
Q=[7 17;15 2];        %将 go qb表示成向量
detP=mod(det(P),26);  %求P的模逆矩阵15
x=1;
while(mod(detP*x,26)~=1)
    x=x+1;
end                   %x=7
P1=[18,-1;-5,4];      %伴随矩阵
P2=mod(x*P1, 26);     %逆矩阵
A=Q*P2;
A=mod(A,26);
disp('密钥矩阵为')
disp(A);
dA=mod(det(A),26);    %求A的模逆矩阵K
y=1;
while(mod(dA*y,26)~=1)
    y=y+1;
end                   %y=9
A1=[A(2,2),-A(1,2);-A(2,1),A(1,1)];
A2=mod(y*A1,26);
disp('解密矩阵为')
disp(A2)