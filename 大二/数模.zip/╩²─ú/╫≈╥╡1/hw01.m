% 1表示黑棋  -1表示白棋
clc;
clear;
N = input("please input a number：");        % 输入棋子数量
arr = (-1).^randi(2, 1, N)                   % 随机生成数组
% arr = [1 -1 -1 1 1 -1 -1 -1]
times = 1;
while(min(arr) == -1)                        % 结束条件为全部为黑棋
    start = arr(1);
    for i = 1:N-1
        arr(i) = arr(i)*arr(i+1);
    end
    arr(N) = start*arr(N);
    fprintf('第%d次循环：\n',times);
    disp(arr);                               % 控制台记录输出状态
    times = times + 1;
end
    