clear, clc;
P = [4 5;1 18];     % 明文矩阵
Q = [7 15;17 2];    % 密文矩阵
A = (Q^(-1) * P)'
% A = [1, 11; 0, 3];
% 破译过程
A = [1 5; 0 9];
codeStr = 'goqbxcbuglosnfal';
code = [];      % 存储密文矩阵
for i = 1:length(codeStr)
    if (mod(i,2) == 0)
        code(2, i/2) = codeStr(i) - 'a' + 1;
    else
        code(1, (i + 1) /2) = codeStr(i) - 'a' + 1;
    end
end
disp(code);
B = mod(A * code, 26);   % 存储明文矩阵
disp(B);
output = '';        % 存储明文字符串
index = 1;
for i = 1:length(codeStr)
    if (mod(i,2) == 0)
        output(index) = B(2, i / 2) + 'a' - 1;
    else
        output(index) = B(1, (i + 1) /2) + 'a' - 1;
    end
    index = index + 1;
end
disp(output);

