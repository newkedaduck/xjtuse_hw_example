import re
import jieba
from jieba.analyse import extract_tags
from openpyxl import load_workbook
from wordcloud import WordCloud
import matplotlib.pyplot as plt
import cv2
from docx import Document
from docx.shared import Inches


def fun1():
    # 读取xlsx中的工作表Sheet1
    workbook = load_workbook('职位.xlsx')
    print(type(workbook))
    worksheet = workbook['Sheet1']
    # 将Sheet1中F列内容写入txt文件
    data = []
    with open('职位信息.txt', 'w') as f:  # 使用with语句自动关闭文件
        for row in range(2, worksheet.max_row + 1):
            data.append(worksheet['F'+str(row)].value)
        f.write(str(data))


def fun2():
    with open('职位信息.txt', 'r', encoding='gbk') as f:
        content = f.read()
        cleaned_content = re.sub('<.*?>', '', content)  # 移除HTML标签
        cleaned_content = re.sub('&nbsp;', '', cleaned_content)  # &nbsp HTML实体
        cleaned_content = re.sub(' ', '', cleaned_content)  # 移除所有空白字符

    with open('职位信息-清洗后.txt', 'w', encoding='gbk') as h:
        h.write(cleaned_content)

def fun3():
    # 分词
    f = open('职位信息-清洗后.txt', 'r', encoding='gbk').read()
    sep_list = jieba.lcut(f)
    print('分词', type(sep_list), len(sep_list), sep_list)

def fun4():
    # fun3()
    f = open('职位信息-清洗后.txt', 'r', encoding='gbk').read()
    sep_list = jieba.lcut(f)
    stopwords = [line.strip() for line in open('stop.txt', 'r', encoding='utf-8').readlines()]
    print('停用词',type(stopwords), stopwords)

    outstr = ''
    for word in sep_list:
        if word not in stopwords:
            outstr += word
    print('过滤停用词后', type(outstr), outstr)

def fun5():
    # fun4()
    f = open('职位信息-清洗后.txt', 'r', encoding='gbk').read()
    sep_list = jieba.lcut(f)
    stopwords = [line.strip() for line in open('stop.txt', 'r', encoding='utf-8').readlines()]
    print('停用词',type(stopwords), stopwords)
    outstr = ''
    for word in sep_list:
        if word not in stopwords:
            outstr += word
    print('过滤停用词后', type(outstr), outstr)

    # outstr = jieba.lcut(outstr)
    # outstr = ' '.join(outstr)
    # print('再次分词后', type(outstr), outstr)

def fun6():
    # fun5()
    f = open('职位信息-清洗后.txt', 'r', encoding='gbk').read()
    sep_list = jieba.lcut(f)
    stopwords = [line.strip() for line in open('stop.txt', 'r', encoding='utf-8').readlines()]
    print('停用词',type(stopwords), stopwords)
    outstr = ''
    for word in sep_list:
        if word not in stopwords:
            outstr += word
    print('过滤停用词后', type(outstr), outstr)

    outstr = jieba.lcut(outstr)
    outstr = ' '.join(outstr)
    print('再次分词后', type(outstr), outstr)

    font = r'C:\Windows\Fonts\simsun.ttc'
    # font = "Fonts/STXINGKA.TTF"
    wc = WordCloud(background_color="white", font_path=font, width=2400, height=1600, max_words=100)
    wc.generate(outstr)
    wc.to_file('词云.jpg')
    plt.figure(dpi=100)
    plt.imshow(wc, interpolation='catrom')
    plt.axis('off')
    plt.show()
    plt.close()
    for keyword, weight in extract_tags(outstr, topK=50, withWeight=True, allowPOS=()):
        print('%s %s' % (keyword, weight))

def fun7():
    # img = cv2.imread('qianzi.jpg')
    # img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    # ret, img1 = cv2.threshold(img, 125, 255, cv2.THRESH_BINARY)
    # img2 = cv2.cvtColor(img1, cv2.COLOR_GRAY2BGRA)
    # print(img2.shape)
    # for i in range(img2.shape[0]):
    #     for j in range(img2.shape[1]):
    #         if img2[i,j][0] == 255:
    #             img2[i,j][3] = 0
    # img3 = cv2.imwrite('qianzi-binary.png', img2)
    # 读取工程文件下的图片，也可使用绝对路径，cv2读取的是BGR格式
    img = cv2.imread('qianzi.jpg')
    # BGR转灰度图
    img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    # 二值化，调整thresh值（125）直到获得较好结果
    ret, img1 = cv2.threshold(img, 125, 255, cv2.THRESH_BINARY)
    img4 = cv2.imwrite('qianzi-binary.jpg', img1)
    # 转为BGRA，带透明度的四通道
    img2 = cv2.cvtColor(img1, cv2.COLOR_GRAY2BGRA)
    # 图片shape属性是tuple类型，元组
    print(img2.shape)
    # 遍历所有像素，白色像素（255）的透明度设置为透明（0）
    for i in range(img2.shape[0]):
        for j in range(img2.shape[1]):
            if img2[i, j][0] == 255:
                img2[i, j][3] = 0
    # 保存为新图片
    img3 = cv2.imwrite('qianzi-binary.png', img2)

def fun8():
    img = cv2.imread('qianzi.jpg')
    img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    ret, img1 = cv2.threshold(img, 125, 255, cv2.THRESH_BINARY)
    img4 = cv2.imwrite('qianzi-binary.jpg', img1)
    img2 = cv2.cvtColor(img1, cv2.COLOR_GRAY2BGRA)
    print(img2.shape)
    for i in range(img2.shape[0]):
        for j in range(img2.shape[1]):
            if img2[i, j][0] == 255:
                img2[i, j][3] = 0
    img3 = cv2.imwrite('qianzi-binary.png', img2)

def fun9():
    wb = load_workbook('简历信息.xlsx')
    ws = wb.active

def fun10():
    # 替换word中的关键词
    def info_update(doc, old_info, new_info):
        # 遍历替换所有段落中的关键词
        for para in doc.paragraphs:
            for run in para.runs:
                run.text = run.text.replace(old_info, new_info)
        # 遍历替换所有表格中的关键词
        for table in doc.tables:
            for row in table.rows:
                for cell in row.cells:
                    cell.text = cell.text.replace(old_info, new_info)

    # 读取excel中的信息
    wb = load_workbook('简历信息.xlsx')
    ws = wb.active
    # 根据简历信息中的每行生成一个简历，即为每个公司生成一份专属简历
    for row in range(2, ws.max_row + 1):
        doc = Document('简历模板.docx')
        for col in range(1, ws.max_column + 1):
            # 简历信息中的标题，对应word中的关键词
            old_info = str(ws.cell(row=1, column=col).value)
            # 简历信息中的替换的具体公司关键词
            new_info = str(ws.cell(row=row, column=col).value)
            # 执行替换
            info_update(doc, old_info, new_info)
        # 插入电子签名
        # 在word中的第2个表格的（0，1）单元格插入图片
        table = doc.tables[1]
        run = table.cell(0, 1).paragraphs[0].add_run('')
        run.add_picture('qianzi-binary.png', width=Inches(1), height=Inches(0.5))
        # 基于更新后的简历模板生成以对应公司命名的简历
        com_name = str(ws.cell(row=row, column=1).value)
        doc.save(f'{com_name}简历.docx')

def fun11():
    # 读取excel文件工作表Sheet1
    workbook = load_workbook('职位.xlsx')
    worksheet = workbook['Sheet1']
    # 将Sheet1中F列内容写入txt文件
    data = []
    f = open('职位信息.txt', 'w')
    for row in range(2, worksheet.max_row + 1):
        data.append(worksheet['F' + str(row)].value)
    f.write(str(data))
    f.close()

    # 去除html标签
    f = open('职位信息.txt', 'r').read()
    g = re.sub('<.*?>', '', f)
    g = re.sub('&nbsp;', '', g)
    g = re.sub('  ', '', g)
    # 清洗后数据写入新的txt
    h = open('职位信息-清洗后.txt', 'w')
    h.write(g)
    h.close()

    # 生成词云
    # 读取txt
    f = open('职位信息-清洗后.txt', 'r', encoding='gbk').read()
    # 分词
    sep_list = jieba.lcut(f)
    print('分词', type(sep_list), len(sep_list), sep_list)
    # 过滤停用词
    # stopwords为停用词list，stop.txt停用词一行一个
    stopwords = [line.strip() for line in open('stop.txt', 'r', encoding='utf-8').readlines()]
    print('停用词', type(stopwords), stopwords)
    outstr = ''
    for word in sep_list:
        if word not in stopwords:
            outstr += word
    print('过滤停用词后', type(outstr), outstr)
    # 过滤后重新分词
    outstr = jieba.lcut(outstr)
    outstr = ' '.join(outstr)
    print('再次分词后', type(outstr), outstr)
    # 生成词云图
    # 设置词云使用的字体
    font = "Fonts/STXINGKA.TTF"
    # font = r'C:\Windows\Fonts\simsun.ttc'
    wc = WordCloud(background_color="white" ,font_path=font, width=2400, height=1200, max_words=100)
    wc.generate(outstr)
    wc.to_file('词云.jpg')
    plt.figure(dpi=100)
    plt.imshow(wc, interpolation='catrom')
    plt.axis('off')
    plt.show()
    plt.close()

    # 生成词频
    for keyword, weight in extract_tags(outstr, topK=50, withWeight=True, allowPOS=()):
        print('%s %s' % (keyword, weight))

if __name__ == '__main__':
    fun11();