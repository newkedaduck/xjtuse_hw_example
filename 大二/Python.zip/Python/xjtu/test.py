import matplotlib.pyplot as plt
import numpy as np

# 假设我们有一个二维网格上的x和y坐标，以及对应的u和v分量
X, Y = np.mgrid[-5:5:20j, -5:5:20j]
U = np.cos(np.sqrt(X ** 2 + Y ** 2))
V = np.sin(np.sqrt(X ** 2 + Y ** 2))

# 绘制矢量场
plt.quiver(X, Y, U, V, scale=50, width=0.005, headwidth=5, headlength=7, headaxislength=4.5, color="C0")

# 添加其他设置，如标题、轴标签等
plt.title('Quiver Plot')
plt.xlabel('X')
plt.ylabel('Y')

# 显示图形
plt.show()