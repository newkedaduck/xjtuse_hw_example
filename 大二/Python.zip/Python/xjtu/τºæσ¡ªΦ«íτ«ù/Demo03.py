import numpy as np
import pylab as pl
from scipy import linalg
import matplotlib as mpl
import matplotlib.pyplot as plt
from math import sin, cos
from scipy import optimize
from scipy.sparse import csgraph
import subprocess
from scipy import sparse

def fun1():
    x = np.arange(15, dtype=np.int64).reshape(3, 5)
    x[1:, ::2] = -99
    print(x)
    print(x.max(axis=1))
    rng = np.random.default_rng()
    samples = rng.normal(size=2500)
    print(samples.shape)

def fun2():
    A = np.array([[1,2],[3,4]])
    linalg.inv(A)

def fun3():
    fig, ax = plt.subplots()
    ax.plot([1,2,3,4],[1,4,2,3])
    plt.show()

def fun4():
    """
    非线性方程组求解
    """
    def f(x):
        x0, x1, x2 = x.tolist()
        return [
            5*x1 + 3,
            4*x0*x0 - 2*sin(x1*x2),
            x1*x2 - 1.5
        ]
    # f计算方程组的误差，[1,1,1]是未知数的初始值
    result = optimize.fsolve(f, [1,1,1])
    print(result)
    print(f(result))

def fun5():
    X = np.array([8.19, 2.72, 6.39, 8.71, 4.7, 2.66, 3.78])
    Y = np.array([7.01, 2.78, 6.47, 6.71, 4.1, 4.23, 4.05])

    def residuals(p):
        k, b = p
        return Y - (k*X + b)

    r = optimize.leastsq(residuals, [1, 0])
    k, b = r[0]
    print("k = ", k, "b = ", b)

def fun6():
    """
    最小二乘法拟合
    """
    pl.rcParams['font.sans-serif'] = [u'SimHei']    # 正确显示中文
    pl.rcParams['axes.unicode_minus'] = False       # 正确显示负号

    # 带噪声的正弦波拟合
    def func(x, p):
        """
        数据拟合所用的函数: A*sin(2*pi*k*x + theta)
        """
        A, k, theta = p         # 待拟合的参数
        return A * np.sin(2 * np.pi * k * x + theta)

    def residuals(p, y, x):
        """
        残差函数：即实验数据 y 和通过 func(x, p) 计算出的理论值之间的差。
        用于在优化过程中被用来评估参数的好坏。
        """
        return y - func(x, p)

    x = np.linspace(0, 2 * np.pi, 100)      # 0到2pi的100个点
    A, k, theta = 10, 0.34, np.pi / 6       # 真实数据的函数参数
    y0 = func(x, [A, k, theta])             # 真实数据y0
    # 加入噪声之后的实验数据
    """
    在真实数据 y0 上添加随机噪声生成实验数据 y1
    这里使用了正态分布的随机数，并设置了随机种子 ,以确保结果的可重复性
    """
    np.random.seed(0)
    y1 = y0 + 2 * np.random.randn(len(x))   # 从标准正态分布（均值为0，标准差为1）中生成随机数。

    p0 = [7, 0.40, 0]                       # 拟合参数的初始猜测值 p0
    """
    调用leastsq进行数据拟合:leastsq 会尝试找到使残差最小的参数值
    args为需要拟合的实验数据
    """
    plsq = optimize.leastsq(residuals, p0, args=(y1, x))

    print(u"真实参数:", [A, k, theta])
    print(u"拟合参数", plsq[0])             # 实验数据拟合后的参数

    pl.plot(x, y1, "o", label=u"带噪声的实验数据")
    pl.plot(x, y0, label=u"真实数据")
    pl.plot(x, func(x, plsq[0]), label=u"拟合数据")
    pl.legend(loc="best")
    pl.show()

def fun7():
    """
    绘制二维向量场中向量以及它们经过线性变化后的结果
    """
    def draw_arrows(points, **kw):
        """
        绘制向量
        :param points:Numpy数组
        :param kw: 关键词参数字典
        """
        props = dict(color="blue", arrowstyle="->")         # 定义箭头的颜色和样式
        props.update(kw)                                    # 更新默认的属性
        # 使用pl.annotate来绘制一个箭头从(0, 0)指向该点
        for x, y in points:
            pl.annotate("",
                        xy=(x, y), xycoords='data',
                        xytext=(0, 0), textcoords='data',
                        arrowprops=props)

    A = np.array([[1, -0.3], [-0.1, 0.9]])      # 二维矩阵A
    evalues, evectors = linalg.eig(A)           # 计算了矩阵A的特征值和特征向量
    print("evalues:", evalues)
    print("evectors:", evectors)

    # 线性变换将蓝色箭头变换为红色箭头
    points = np.array([[0, 1.0], [1.0, 0], [1, 1]])

    draw_arrows(points)         # 原始向量
    draw_arrows(np.dot(A, points.T).T, color="red")         # 向量经过线性变换后的位置
    draw_arrows(evectors.T, alpha=0.7, linewidth=2)         # 特征向量
    draw_arrows(np.dot(A, evectors).T, color="red", alpha=0.7, linewidth=2) # 特征向量经过线性变换后的位置

    ax = pl.gca()               # 获取当前的坐标轴对象
    ax.set_aspect("equal")      # 设置坐标轴的比例
    ax.set_xlim(-0.5, 1.1)
    ax.set_ylim(-0.5, 1.1)
    pl.show()

def fun8():
    """
    椭圆拟合求解
    """
    # 用广义特征向量计算的拟合椭圆
    def ellipse(p, x, y):
        a, b, c, d, e, f = p            # 椭圆方程参数
        return a * x ** 2 + b * x * y + c * y ** 2 + d * x + e * y + f

    np.random.seed(42)
    t = np.random.uniform(0, 2 * np.pi, 60)         # 60个在[0, 2*pi)之间的均匀分布的角度t
    # 参数
    alpha = 0.4
    a = 0.5
    b = 1.0
    # 借助参数方程生成椭圆上的点
    x = 1.0 + a * np.cos(t) * np.cos(alpha) - b * np.sin(t) * np.sin(alpha)
    y = 1.0 + a * np.cos(t) * np.sin(alpha) - b * np.sin(t) * np.cos(alpha)
    # 添加噪声信号
    x += np.random.normal(0, 0.05, size=len(x)) # 添加了一个来自正态分布 N(0, 0.05^2) 的随机噪声
    y += np.random.normal(0, 0.05, size=len(y))

    D = np.c_[x ** 2, x * y, y ** 2, x, y, np.ones_like(x)]     # 矩阵D：用于拟合椭圆的点的多项式特征
    A = np.dot(D.T, D)          # 用于后续的广义特征值
    C = np.zeros((6, 6))        # 对称矩阵，定义椭圆的形状约束，确保拟合出的椭圆是正的
    C[[0, 1, 2], [2, 1, 0]] = 2, -1, 2
    evalues, evectors = linalg.eig(A, C)  # 广义特征值
    evectors = np.real(evectors)          # 取特征向量的实部
    err = np.mean(np.dot(D, evectors) ** 2, 0)  # 每个特征向量对应的椭圆方程在点集D上的平均误差
    p = evectors[:, np.argmin(err)]  # 选择误差最小的特征向量作为拟合椭圆的参数
    print(p)

    X, Y = np.mgrid[0:2:100j, 0:2:100j]
    Z = ellipse(p, X, Y)
    pl.plot(x, y, "ro", alpha=0.5)
    pl.contour(X, Y, Z, levels=[0])
    pl.show()

def fun9():
    a = sparse.dok_matrix((10, 5))
    a[2, 3] = 1.0
    a[3, 3] = 2.0
    a[4, 3] = 3.0
    print(a.keys())
    print(a.values())

    b = sparse.lil_matrix((10, 5))
    b[2, 3] = 1.0
    b[3, 4] = 2.0
    b[3, 2] = 3.0
    print(b.data)
    print(b.rows)

    print("====================================")
    row = [2, 3, 3, 2]
    col = [3, 4, 2, 3]
    data = [1, 2, 3, 10]
    c = sparse.coo_matrix((data, (row, col)), shape=(5, 6))
    print(c.col, c.row, c.data)
    print(c.toarray())
    print("====================================")


def fun10():
    """
    dijkstra算法求解最短路径
    """
    w = sparse.dok_matrix((4, 4))       # 字典形式的稀疏矩阵
    edges = [(0, 1, 10), (1, 2, 5), (0, 2, 3),
             (2, 3, 7), (3, 0, 4), (3, 2, 6)]   #  (起始节点, 结束节点, 边的权重)
    for i, j, v in edges:
        w[i, j] = v

    w.todense()
    dist_matrix, predecessors = csgraph.dijkstra(csgraph=w, directed=True, indices=0, return_predecessors=True)
    print(dist_matrix)
    print(predecessors)

if __name__ == '__main__':
    fun10();