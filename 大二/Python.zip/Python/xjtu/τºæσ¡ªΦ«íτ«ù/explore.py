import numpy as np
import pylab as pl
from scipy import sparse
from scipy.sparse import csgraph

img = pl.imread("./maze.jpg")           # 读入图片
sx, sy = (400, 979)                     # 起点
ex, ey = (398,  25)                     # 终点
# 二值化图像
binary_img = np.all(img > 0.75 * 255, axis=2)       # 像素 > 0.75 * 255，被视为白色（可走路径）
H, W = binary_img.shape

x0, x1 = np.where(binary_img[H // 2, :] == 0)[0][[0, -1]]
binary_img[H // 2, :x0] = 0
binary_img[H // 2, x1:] = 0     # 中心行上，左右边界之间的所有像素设置为黑色

mask = (binary_img[1:, :] & binary_img[:-1, :])     # 比较相邻两行上的像素值
idx = np.where(mask.ravel())[0]
vedge = np.c_[idx, idx + W]     # 构建垂直边的坐标对
pl.imsave("tmp.png", mask, cmap="gray")

#左右相邻白色像素
mask = (binary_img[:, 1:] & binary_img[:, :-1])     # 查找水平相邻的白色像素对
y, x = np.where(mask)                       # 获取水平边的索引
idx = y * W + x                             # 将二维索引转换为一维索引
hedge = np.c_[idx, idx + 1]                 # 构建水平边的坐标对

edges = np.vstack([vedge, hedge])           # 组合垂直和水平边

values = np.ones(edges.shape[0])            # 设置边的权重
w = sparse.coo_matrix((values, (edges[:, 0], edges[:, 1])),
                      shape=(binary_img.size, binary_img.size))     # 构建稀疏矩阵

startid = sy * W + sx           # 设置起点和终点的一维标记
endid = ey * W + ex
d, p = csgraph.dijkstra(w, indices=[startid], return_predecessors=True, directed=False)

np.isinf(d[0]).sum()        # 检查是否存在不可达节点

path = []       # 路径列表
node_id = endid     # 从终点寻找前缀结点
while True:
    path.append(node_id)
    if node_id == startid or node_id < 0:
        break
    node_id = p[0, node_id]
path = np.array(path)

x, y = path % W, path // W      # 将路径ID转换为图像坐标
img = img.copy()
img[y, x, :] = 0        # 路径上的所有像素设置为黑色
fig, axes = pl.subplots(1, 2, figsize=(16, 12))
axes[0].imshow(img)
axes[1].imshow(binary_img, cmap="gray")
for ax in axes:
    ax.axis("off")
fig.subplots_adjust(0, 0, 1, 1, 0, 0)
pl.show()