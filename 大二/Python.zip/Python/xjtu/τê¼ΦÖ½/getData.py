#Selenium模块是一个自动化测试工具，能够驱动浏览器模拟人的操作，如单击、键盘输入等。
from selenium import webdriver
from selenium.webdriver.common.by import By
import re
import pandas as pd
import time

# 从获取的网页源代码中提取目标数据
def get_data(pagesource):
    # 正则表达式
    p_job = 'class="jname text-cut">(.*?)</span>'
    p_salary = 'class="sal shrink-0">(.*?)</span>'
    p_company = 'class="cname text-cut">(.*?)</a>'

    # 提取目标数据
    job = re.findall(p_job, pagesource, re.S)
    salary = re.findall(p_salary, pagesource, re.S)
    company = re.findall(p_company, pagesource, re.S)

    # 将几个目标数据列表转换为一个字典
    data_dict = {'职位名称': job, '月薪': salary, '公司名称': company}
    return pd.DataFrame(data_dict)

def get_pages(keyword, city, start, end):
    # 声明要模拟的浏览器是Chrome,并启用无界面浏览模式
    chrome_options = webdriver.ChromeOptions()
    chrome_options.add_argument("--disable-blink-features=AutomationControlled")
    browser = webdriver.Chrome(options=chrome_options)
    browser.maximize_window()

    # 获取源码
    url = 'https://www.51job.com/'
    browser.get(url)
    # 模拟人操作浏览器，输入搜索关键词，点击搜索按钮
    # /html/body/div[3]/div/div[1]/div/button
    # //*[@id="kwdselectid"]
    browser.find_element(By.XPATH, '//*[@id="kwdselectid"]').clear()
    browser.find_element(By.XPATH, '//*[@id="kwdselectid"]').send_keys(keyword)
    browser.find_element(By.XPATH, '/html/body/div[3]/div/div[1]/div/button').click()

    time.sleep(10)
    all_data = pd.DataFrame()
    for page in range(start, end + 1):
        # 模拟人操作浏览器，输入搜索关键词，点击搜索按钮
        browser.find_element(By.XPATH, '//*[@id="jump_page"]').clear()
        browser.find_element(By.XPATH, '//*[@id="jump_page"]').send_keys(page)
        browser.find_element(By.XPATH, '//*[@id="app"]/div/div[2]/div/div/div[2]/div/div[2]/div/div[3]/div/div/span[3]').click()
        # 等待浏览器与服务器交互刷新数据，否则获取不到动态信息
        time.sleep(10)
        #将提取的目标数据添加到DataFrame中
        all_data = all_data._append(get_data(browser.page_source))

    browser.quit()

    #将DataFrame保存为Excel
    all_data.to_excel('职位.xlsx', index=False)

get_pages('python', '西安', 1, 4)
