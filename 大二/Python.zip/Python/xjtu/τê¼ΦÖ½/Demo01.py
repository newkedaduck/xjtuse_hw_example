import re
import time

import pandas as pd
import requests
from selenium import webdriver
from selenium.webdriver.common.by import By
import openpyxl

def fun1():
    # print(requests.get('http://www.xjtu.edu.cn').text.encode('ISO-8859-1').decode('utf-8'))
    print(requests.get('http://www.xjtu.edu.cn').text)

def fun2():
    url = 'http://www.xjtu.edu.cn'
    response = requests.get(url)
    print(type(response))
    result = response.text
    result = result.encode('ISO-8859-1').decode('utf-8')
    source = 'xynr.jsp\?urltype=tree\.TreeTempUrl&wbtreeid=\d\d\d\d"><span>(.*?)</span'
    tardata = re.findall(source, result, re.S)
    print(tardata)

def fun3():
    url = 'http://www.51job.com/'
    response = requests.get(url)
    result = response.text
    result = result.encode('ISO-8859-1').decode('gbk')
    print(result)

def fun4():
    """
    使用selenium模块访问网页
    """
    browser = webdriver.Chrome()
    browser.get('http://www.51job.com')

def fun5():
    """
    无界面浏览器模式
    """
    chrome_options = webdriver.ChromeOptions()
    chrome_options.add_argument('--headless')
    browser = webdriver.Chrome(options=chrome_options)
    browser.get('http://www.51job.com')

def fun6():
    """
    获取网页源代码
    """
    chrome_options = webdriver.ChromeOptions()
    chrome_options.add_argument("--disable-blink-features=AutomationControlled")
    browser = webdriver.Chrome(options=chrome_options)
    browser.get('http://www.51job.com')
    data = browser.page_source
    print(data)

def fun7():
    browser = webdriver.Chrome()
    browser.get('http://www.51job.com')
    browser.find_element(By.XPATH, '/html/body/div[3]/div/div[1]/div/button').click()
    input()

def fun8():
    # 声明使用Chrome
    browser = webdriver.Chrome()
    browser.get('http://www.51job.com')
    browser.find_element(By.XPATH, '//*[@id="kwdselectid"]').send_keys('Python工程师')
    browser.find_element(By.XPATH, '/html/body/div[3]/div/div[1]/div/button').click()
    time.sleep(5)

    p_job = 'class="jname text-cut">(.*?)</span>'
    p_salary = 'class="sal shrink-0">(.*?)</span>'
    job = re.findall(p_job, browser.page_source)
    salary = re.findall(p_salary, browser.page_source)
    data = {'岗位':job, '薪水':salary}
    data = pd.DataFrame(data)
    data.to_excel('岗位薪水.xlsx', index=False)

if __name__ == '__main__':
    fun8();