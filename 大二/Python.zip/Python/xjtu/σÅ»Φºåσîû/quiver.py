"""
箭头图
"""
import matplotlib.pyplot as plt
import numpy as np


def fun1():
    """
    二维绘制箭头图
    :return: 2D箭头图
    """
    X, Y = np.mgrid[-5:5:20j, -5:5:20j]
    U = np.cos(np.sqrt(X ** 2 + Y ** 2))
    V = np.sin(np.sqrt(X ** 2 + Y ** 2))
    # 绘制矢量场
    plt.quiver(X, Y, U, V, scale=50, width=0.005, headwidth=5, headlength=7, headaxislength=4.5, color="C0")

    plt.title('Quiver Plot Example')
    plt.xlabel('X')
    plt.ylabel('Y')
    plt.show()


def fun2():
    """
    三维绘制箭头图
    :return: 3D箭头图
    """
    ax = plt.figure().add_subplot(projection='3d')

    # 3维网格
    x, y, z = np.meshgrid(np.arange(-0.8, 1, 0.2),
                          np.arange(-0.8, 1, 0.2),
                          np.arange(-0.8, 1, 0.8))

    # 偏移位置
    u = np.sin(np.pi * x) * np.cos(np.pi * y) * np.cos(np.pi * z)
    v = -np.cos(np.pi * x) * np.sin(np.pi * y) * np.cos(np.pi * z)
    w = (np.sqrt(2.0 / 3.0) * np.cos(np.pi * x) * np.cos(np.pi * y) *
         np.sin(np.pi * z))

    ax.quiver(x, y, z, u, v, w, length=0.1, normalize=True)

    plt.show()

if __name__ == '__main__':
    fun2();