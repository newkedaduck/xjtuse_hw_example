import matplotlib.pyplot as plt
import numpy as np
import matplotlib.cm as cm
import matplotlib.ticker as mticker
from urllib3.connectionpool import xrange


def fun1():
    """
    快速绘图
    :return: sinx和cosx^2的图像
    """
    x = np.linspace(0, 10, 1000)    # 等差数列
    y = np.sin(x)
    z = np.cos(x**2)

    plt.figure(figsize=(8, 4))      # 隐式创建Figure对象
    # 绘制图像
    plt.plot(x, y, label="$sin(x)", color="red", linewidth=2)
    plt.plot(x, z, "b--", label="$cos(x^2)")
    # 图例设置
    plt.xlabel("Time(s)")
    plt.ylabel("Volt")
    plt.title("PyPlot First Example")
    plt.ylim(-1.2, 1.2)             # y轴范围
    plt.legend()
    plt.show()

def fun2():
    """
    图像属性设置
    :return: 透明度为0.5的二次函数图像
    """
    plt.figure(figsize=(4, 3))
    x = np.arange(0, 5, 0.1)            # 等差数列，从0到5（不含5）步长为0.1
    line = plt.plot(x, 0.05*x*x)[0]     # 取出第一条线条
    line.set_alpha(0.5)                 # set_alpha()设置透明度
    plt.show()

def fun3():
    """
    error
    :return:
    """
    plt.figure(1)
    plt.figure(2)
    ax1 = plt.subplots(121)
    ax2 = plt.subplots(122)

    x = np.linspace(0, 3, 100)
    for i in range(5):
        plt.figure(1)
        plt.plot(x, np.exp(i*x/3))
        plt.sca(ax1)
        plt.plot(x, np.sin(i*x))
        plt.sca(ax2)
        plt.plot(x, np.cos(i*x))
    plt.show()


def fun4():
    """
    对数坐标图
    :return: 4个子图，分别以不同的坐标体系
    """
    w = np.linspace(0.1, 1000, 1000)
    p = np.abs(1 / (1 + 0.1j * w))  # 计算低通滤波器的频率响应

    fig, axes = plt.subplots(2, 2)  # 2x2的子图
    functions = ("plot", "semilogx", "semilogy", "loglog")
    #            算术       x轴对数      y轴对数       双对数
    for ax, fname in zip(axes.ravel(), functions):
        func = getattr(ax, fname)
        func(w, p, linewidth=2)
        ax.set_ylim(0, 1.5)
    plt.show()

def fun5():
    """
    柱状图
    :return:中国男女人口的年龄分布图
    """
    data = np.loadtxt("china_population.txt")       # 加载文本对象返回一个numpy数组
    width = (data[1, 0] - data[0, 0]) * 0.4         # 间距
    plt.figure(figsize=(8, 4))
    plt.rcParams["font.sans-serif"] = ["Microsoft YaHei"]   # 显示中文字体
    c1 = 'red'
    c2 = 'blue'
    # 绘制柱形图
    plt.bar(data[:, 0] - width/2, data[:, 1] / 1e7, width, color=c1, label=u"男")
    plt.bar(data[:, 0] + width/2, data[:, 2] / 1e7, width, color=c2, label=u"女")
    plt.xlim(-width * 1.5, 100)
    plt.xlabel(u"年龄")
    plt.ylabel(u"人口（千万）")
    plt.legend()
    plt.show()

def fun6():
    """
    散列图
    """
    plt.figure(figsize=(8, 4))
    x = np.random.random(100)       # 生成100个随机x坐标
    y = np.random.random(100)       # 生成100个随机y坐标
    plt.scatter(x, y, s=x * 1000, c=y, marker=(5, 1),   # marker表示5边形，旋转角度为1
                alpha=0.8, lw=2, facecolors="none")     # s是面积
    plt.xlim(0, 1)
    plt.ylim(0, 1)
    plt.show()

def fun7():
    """
    图像处理
    """
    img = plt.imread("lena.jpg")    # 读入图片
    fig, axes = plt.subplots(2, 4, figsize=(11, 4))
    fig.subplots_adjust(0, 0, 1, 1, 0.05, 0.05)
    axes = axes.ravel()
    axes[0].imshow(img)
    axes[1].imshow(img, origin="lower")
    axes[2].imshow(img * 1.0)
    axes[3].imshow(img / 255.0)
    axes[4].imshow(np.clip(img / 200.0, 0, 1))

    axe_img = axes[5].imshow(img[:, :, 0])
    plt.colorbar(axe_img, ax=axes[5])

    axe_img = axes[6].imshow(img[:, :, 0], cmap="copper")
    plt.colorbar(axe_img, ax=axes[6])

    for ax in axes:
        ax.set_axis_off()
    plt.show()
    # cmap_names = list(cm.cmap_d.keys())     # 没有cmap_d属性
    # cmap_names = plt.colormaps()
    # print(cmap_names[:5])
    # plt.show()

def fun8():
    """
    等值线图
    """
    y, x = np.ogrid[-2:2:200j, -3:3:300j]  # ogrid方法
    z = x * np.exp(- x ** 2 - y ** 2)
    extent = [np.min(x), np.max(x), np.min(y), np.max(y)]   # 范围
    plt.figure(figsize=(10, 4))
    plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']   # 中文显示
    plt.subplot(121)
    cs = plt.contour(z, 10, extent=extent)  # 等值线图
    plt.clabel(cs)  # 图例
    plt.subplot(122)
    plt.contourf(x.reshape(-1), y.reshape(-1), z, 20)  # 填充等值线图
    plt.show()


def fun10():
    """
    示例箭头图——矢量场
    """
    def f(x, y):
        return x * np.exp(- x ** 2 - y ** 2)

    def vec_field(f, x, y, dx=1e-6, dy=1e-6):
        x2 = x + dx
        y2 = y + dy
        v = f(x, y)
        vx = (f(x2, y) - v) / dx
        vy = (f(x, y2) - v) / dy
        return vx, vy

    plt.figure(figsize=(6, 4))
    X, Y = np.mgrid[-2:2:20j, -2:2:20j]
    C = f(X, Y)
    U, V = vec_field(f, X, Y)
    plt.quiver(X, Y, U, V, C)
    plt.colorbar()
    plt.gca().set_aspect("equal")
    plt.show()

def fun11():

    plt.figure(figsize=(8, 4))
    n = 40
    arrow_size = 16
    t = np.linspace(0, 1, 1000)
    x = np.sin(3 * 2 * np.pi * t)
    y = np.cos(5 * 2 * np.pi * t)
    line, = plt.plot(x, y, lw=1)

    lengths = np.cumsum(np.hypot(np.diff(x), np.diff(y)))
    length = lengths[-1]
    arrow_locations = np.linspace(0, length, n, endpoint=False)
    index = np.searchsorted(lengths, arrow_locations)
    dx = x[index + 1] - x[index]
    dy = y[index + 1] - y[index]
    ds = np.hypot(dx, dy)
    dx /= ds
    dy /= ds
    plt.quiver(x[index], y[index], dx, dy, t[index],
               units="dots", scale_units="dots",
               angles="xy", scale=1.0 / arrow_size, pivot="middle",
               edgecolors="black", linewidths=1,
               width=1, headwidth=arrow_size * 0.5,
               headlength=arrow_size, headaxislength=arrow_size,
               zorder=100)
    plt.colorbar()
    plt.xlim([-1.5, 1.5])
    plt.ylim([-1.5, 1.5])
    plt.show()

def fun12():
    # %fig=使用quiver()绘制神经网络结构示意图
    plt.figure(figsize=(7, 4))
    levels = [4, 5, 3, 2]
    x = np.linspace(0, 1, len(levels))

    for i in range(len(levels) - 1):
        j = i + 1
        n1, n2 = levels[i], levels[j]
        y1, y2 = np.mgrid[0:1:n1 * 1j, 0:1:n2 * 1j]
        x1 = np.full_like(y1, x[i])
        x2 = np.full_like(y2, x[j])
        plt.quiver(x1, y1, x2 - x1, y2 - y1,
                   angles="xy", units="dots", scale_units="xy",
                   scale=1, width=2, headlength=10,
                   headaxislength=10, headwidth=4)

    yp = np.concatenate([np.linspace(0, 1, n) for n in levels])
    xp = np.repeat(x, levels)
    plt.plot(xp, yp, "o", ms=12)
    plt.gca().axis("off")
    plt.margins(0.1, 0.1)
    plt.show()

def fun13():
    """
    三维绘图
    """
    x, y = np.mgrid[-2:2:20j, -2:2:20j]  # 网格数据
    z = x * np.exp(- x ** 2 - y ** 2)

    fig = plt.figure(figsize=(8, 6))
    ax = plt.subplot(111, projection='3d')  # projection表示3D
    ax.plot_surface(x, y, z, rstride=2, cstride=1, cmap=plt.cm.Blues_r)  # 颜色映射
    ax.set_xlabel("X")
    ax.set_ylabel("Y")
    ax.set_zlabel("Z")
    plt.show()


def fun14():
    """
    子图测试
    """
    fig = plt.figure()  # 创建一个Figure对象

    colors = "rgbyck"
    for idx, color in enumerate(colors):
        ax = fig.add_subplot(3, 2, idx + 1, facecolor=color)  # 添加Axes对象并设置facecolor

    plt.tight_layout()  # 自动调整子图参数，使之填充整个图像区域
    plt.show()
    # for idx, color in enumerate("rgbyck"):
    #     plt.subplots(321+idx, axisbg=color)     # axisbg 参数在较新版本的中已被弃用，取而代之的是facecolor 或 fc
    plt.show()

def fun15():
    x = np.linspace(0, 2*np.pi, 100)
    y = np.sin(x)
    plt.rcParams["font.sans-serif"] = ["Microsoft YaHei"]   # 显示中文字体
    plt.plot(x, y)
    plt.xlabel('x轴')
    plt.ylabel('y轴')
    plt.title('sin(x)图像')
    plt.legend()
    plt.show()


if __name__ == '__main__':
    fun15();
