"""
波形图
"""
import matplotlib.pyplot as plt
import numpy as np


def fun1():
    x = np.arange(0, 10, 2)
    ay = [1, 1.25, 2, 2.75, 3]
    by = [1, 1, 1, 1, 1]
    cy = [2, 1, 2, 1, 2]
    y = np.vstack([ay, by, cy])
    fig, ax = plt.subplots()

    ax.stackplot(x, y)

    ax.set(xlim=(0, 8), xticks=np.arange(1, 8),
           ylim=(0, 8), yticks=np.arange(1, 8))

    plt.show()

def fun2():
    # Fixing random state for reproducibility
    np.random.seed(19680801)

    def gaussian_mixture(x, n=5):
        """Return a random mixture of *n* Gaussians, evaluated at positions *x*."""

        def add_random_gaussian(a):
            amplitude = 1 / (.1 + np.random.random())
            dx = x[-1] - x[0]
            x0 = (2 * np.random.random() - .5) * dx
            z = 10 / (.1 + np.random.random()) / dx
            a += amplitude * np.exp(-(z * (x - x0)) ** 2)

        a = np.zeros_like(x)
        for j in range(n):
            add_random_gaussian(a)
        return a

    x = np.linspace(0, 100, 101)
    ys = [gaussian_mixture(x) for _ in range(3)]

    fig, ax = plt.subplots()
    ax.stackplot(x, ys, baseline='sym')          # 'wiggle'
    plt.show()

def fun3():

    x = np.linspace(0, 20, 20)
    y1 = np.random.rand(20)
    y2 = np.random.rand(20)
    y3 = np.random.rand(20)

    # 使用stackplot绘制堆叠面积图
    plt.stackplot(x, y1, y2, y3, labels=['Series 1', 'Series 2', 'Series 3'], baseline='sym')

    # 添加图例
    plt.legend()

    # 显示图形
    plt.show()


if __name__ == '__main__':
    fun3();