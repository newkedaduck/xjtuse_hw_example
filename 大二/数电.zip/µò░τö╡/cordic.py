import math

N = 40
K = 0.6072529350088812561694

angles = []

def init():
    for i in range(0, N):
        angles.append(math.atan(math.pow(2, -i))*180.0/math.pi)

def cordic(angle):
    x = K
    y = 0.0
    z = angle
    for i in range(0, N):
        xi = 0.0
        yi = 0.0
        di = 0.0
        if z >= 0 :
            di = 1.0
        else:
            di = -1.0
        
        xi = x - di * y * math.pow(2, -i)
        yi = di * x * math.pow(2, -i) + y
        z -= di * angles[i]

        x = xi
        y = yi
    
    return x, y

def main():
    init()
    angle = [30.0, 45.0, 60.0]
    for i in angle:
        x,y = cordic(i)
        print(f"theta:{i}, cos:{x}, sin{y}")

main()
