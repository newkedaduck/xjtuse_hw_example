def draw_line_dda(x0, y0, x1, y1):
    """
    使用DDA算法绘制直线。
    
    参数:
    x0, y0 - 直线的起始点坐标
    x1, y1 - 直线的结束点坐标
    
    返回值:
    一个包含直线上所有点的列表，每个点是一个(x, y)元组。
    """
    # 计算x和y方向上的距离
    dx = abs(x1 - x0)
    dy = abs(y1 - y0)
    
    # 确定步数，基于x和y方向上的最大距离
    steps = max(dx, dy)
    
    # 计算每个步骤中x和y的增量
    x_increment = (x1 - x0) / float(steps)
    y_increment = (y1 - y0) / float(steps)
    
    # 初始化起始点
    x = x0
    y = y0
    
    # 用于存储所有点的列表
    points = []
    
    # 根据步数添加点到列表中
    for _ in range(int(steps + 1)):
        points.append((round(x), round(y)))
        x += x_increment
        y += y_increment
    
    # 返回所有点的列表
    return points

def draw_line_bresenham(x0, y0, x1, y1):
    """
    使用Bresenham算法绘制从(x0, y0)到(x1, y1)的直线。
    
    参数:
    x0, y0 -- 直线的起始点坐标
    x1, y1 -- 直线的结束点坐标
    
    返回:
    points -- 直线上的点列表
    """
    points = []
    # 计算在x和y方向上的差值
    dx = abs(x1 - x0)
    dy = abs(y1 - y0)
    # 确定x和y方向上的步长
    sx = 1 if x0 < x1 else -1
    sy = 1 if y0 < y1 else -1
    # 初始化误差
    err = dx - dy
    
    while True:
        # 添加当前点到直线点列表
        points.append((x0, y0))
        # 如果当前点与终点重合，则直线绘制完成，退出循环
        if x0 == x1 and y0 == y1:
            break
        # 计算误差的两倍
        e2 = 2 * err
        # 根据误差判断是否需要在x方向上移动
        if e2 > -dy:
            err -= dy
            x0 += sx
        # 根据误差判断是否需要在y方向上移动
        if e2 < dx:
            err += dx
            y0 += sy
    
    return points

def draw_line_midpoint(x0, y0, x1, y1):
    points = []
    dx = abs(x1 - x0)
    dy = abs(y1 - y0)
    steep = dy > dx
    # 如果斜率大于1，则交换x和y进行计算，最后再换回来
    if steep:
        x0, y0 = y0, x0
        x1, y1 = y1, x1
    # 如果起始点的x坐标大于结束点的x坐标，则交换两点，确保从左到右绘制
    if x0 > x1:
        x0, x1 = x1, x0
        y0, y1 = y1, y0
    dx = x1 - x0
    dy = abs(y1 - y0)
    error = dx // 2
    ystep = 1 if y0 < y1 else -1
    y = y0
    # 根据中点画线算法计算并添加点到列表中
    for x in range(x0, x1 + 1):
        coord = (y, x) if steep else (x, y)
        points.append(coord)
        error -= dy
        if error < 0:
            y += ystep
            error += dx
    return points


import matplotlib.pyplot as plt


def plot_line_algorithm(draw_function, x0, y0, x1, y1):
    # 调用绘图函数获取点列表
    points = draw_function(x0, y0, x1, y1)
    
    # 提取x和y坐标为两个列表
    xs, ys = zip(*points)
    
    # 创建一个新的图形
    plt.figure()
    
    # 绘制理想直线
    line_x = [x0, x1]
    line_y = [y0, y1]
    plt.plot(line_x, line_y, 'b-', label='Ideal Line')
    
    # 绘制每个点，并以点的形式展示
    plt.scatter(xs, ys, color='red', label='Discrete Points')
    
    # 设置图形属性
    plt.title(f'{draw_function.__name__} Line Algorithm')
    plt.xlabel('X Axis')
    plt.ylabel('Y Axis')
    plt.legend()
    plt.grid(True)
    plt.axis('equal')
    
    # 显示图形
    plt.show()

import timeit


dda_time = timeit.timeit(lambda: draw_line_dda(0, 0, 2000, 1000), number=1000)
print(f"DDA算法运行时间: {dda_time} 秒")

bresenham_time = timeit.timeit(lambda: draw_line_bresenham(0, 0, 2000, 1000), number=1000)
print(f"Bresenham算法运行时间: {bresenham_time} 秒")


midpoint_time = timeit.timeit(lambda: draw_line_midpoint(0, 0, 2000, 1000), number=1000)
print(f"中点画线算法运行时间: {midpoint_time} 秒")